<div class="main">
    <div class="content" style="text-align: center">
        <div class="register_account" style="text-align:center;display:inline-block;float: none">
            <p>Order Sucessfully Placed.</p>
           
        </div>  	
        <div class="clear"></div>
    </div>
</div>